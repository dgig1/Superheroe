export default function HeroCard({ hero }) {
    const { name, powerstats, image } = hero;
    return (
      <article>
        <img src={image.url} alt={`${name}'s image`} />
        <h1>{name}</h1>
        <p>
          Intelligence:{" "}
          <span
            style={{
              width: `${powerstats.intelligence}%`,
              backgroundColor: "#F9B32F",
            }}
          ></span>
        </p>
        <p>
          Strength:{" "}
          <span
            style={{
              width: `${powerstats.strength}%`,
              backgroundColor: "#FF7C6C",
            }}
          ></span>
        </p>
      </article>
    );
  }
  