import "Superheroe/src/heroes/globals.css";

export const metadata = {
  title: "Superheroes App",
  description: "Exibição de heróis usando API",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
