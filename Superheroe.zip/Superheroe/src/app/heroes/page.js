import HeroCard from "Superheroe/components/HeroCard";

const BASE_URL = "https://superheroapi.com/api.php/4995282617154105/";
const ACCESS_TOKEN = "1bc518e0c6e9483484ea8c8198fdf8bc";

async function fetchHero(id) {
  const res = await fetch(`${BASE_URL}${id}`);
  if (!res.ok) throw new Error("Falha ao buscar os dados");
  return res.json();
}

export default async function HeroesPage() {
  const heroIds = [200, 465]; // IDs dos heróis
  const heroes = await Promise.all(heroIds.map(fetchHero));

  return (
    <div id="heroes">
      {heroes.map((hero) => (
        <HeroCard key={hero.id} hero={hero} />
      ))}
    </div>
  );
}
